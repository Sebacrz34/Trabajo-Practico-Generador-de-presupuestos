// app.js - lógica del generador de presupuestos
// IVA configurable:
const VAT_RATE = 0.21; // 21% por defecto (cambia este valor si necesitas otro %)
const MAX_ROWS = 5;

document.addEventListener('DOMContentLoaded', function () {
  // mostrar fecha y bindear eventos
  document.getElementById('quoteDate').textContent = new Date().toLocaleDateString();
  bindEvents();
  calculate(); // cálculo inicial
});

function bindEvents() {
  // inputs (qty, price, selects) recalculan automáticamente al cambiar
  for (let i = 1; i <= MAX_ROWS; i++) {
    const qty = document.getElementById(`qty${i}`);
    const price = document.getElementById(`price${i}`);
    const prod = document.getElementById(`product${i}`);

    if (qty) qty.addEventListener('input', calculate);
    if (price) price.addEventListener('input', calculate);
    if (prod) prod.addEventListener('change', calculate);
  }

  document.getElementById('calculateBtn').addEventListener('click', calculate);
  document.getElementById('printBtn').addEventListener('click', () => printOrPdf(false));
  document.getElementById('pdfBtn').addEventListener('click', () => printOrPdf(true));
  document.getElementById('resetBtn').addEventListener('click', resetForm);
  document.getElementById('clientName').addEventListener('input', updateClientDisplay);
}

function updateClientDisplay() {
  const name = document.getElementById('clientName').value || '-';
  document.getElementById('clientDisplay').textContent = name;
}

function calculate() {
  let subtotal = 0;

  for (let i = 1; i <= MAX_ROWS; i++) {
    const qty = parseFloat(document.getElementById(`qty${i}`).value) || 0;
    const price = parseFloat(document.getElementById(`price${i}`).value) || 0;
    const lineTotal = round2(qty * price);

    document.getElementById(`lineTotal${i}`).textContent = formatNum(lineTotal);

    subtotal += lineTotal;
  }

  subtotal = round2(subtotal);
  const vat = round2(subtotal * VAT_RATE);
  const total = round2(subtotal + vat);

  // Ahora 12: sin interés
  const ahora12_total = total;
  const ahora12_cuota = round2(ahora12_total / 12);

  // Ahora 18: 75% de interés (especificado por el requerimiento)
  const ahora18_total = round2(total * 1.75); // total + 75%
  const ahora18_cuota = round2(ahora18_total / 18);

  // mostrar resultados
  document.getElementById('subtotal').textContent = formatNum(subtotal);
  document.getElementById('vat').textContent = formatNum(vat);
  document.getElementById('total').textContent = formatNum(total);

  document.getElementById('ahora12_total').textContent = formatNum(ahora12_total);
  document.getElementById('ahora12_cuota').textContent = formatNum(ahora12_cuota);

  document.getElementById('ahora18_total').textContent = formatNum(ahora18_total);
  document.getElementById('ahora18_cuota').textContent = formatNum(ahora18_cuota);

  updateClientDisplay();
}

// util: redondeo a 2 decimales (evita errores flotantes)
function round2(num) {
  return Math.round((Number(num) + Number.EPSILON) * 100) / 100;
}

// util: formato simple a 2 decimales
function formatNum(num) {
  return Number(num).toFixed(2);
}

// Imprime o lanza export a PDF (usa diálogo de impresión del navegador):
function printOrPdf(isPdf) {
  const printable = buildPrintableHtml();
  const w = window.open('', '_blank', 'width=900,height=700');
  w.document.open();
  w.document.write(printable);
  w.document.close();

  // Esperar un poquito y llamar a imprimir
  setTimeout(() => {
    w.focus();
    w.print();
    // no cerramos inmediatamente para que el usuario pueda elegir "Guardar como PDF"
    // w.close();
  }, 300);
}

// Construye HTML limpio para imprimir (reemplaza inputs por texto)
function buildPrintableHtml() {
  const clientName = document.getElementById('clientName').value || '-';
  const date = new Date().toLocaleDateString();

  // reconstruir tabla con las filas donde haya cantidad o precio > 0 o producto seleccionado
  let rowsHtml = '';
  for (let i = 1; i <= MAX_ROWS; i++) {
    const product = document.getElementById(`product${i}`).value || '';
    const qty = parseFloat(document.getElementById(`qty${i}`).value) || 0;
    const price = parseFloat(document.getElementById(`price${i}`).value) || 0;
    const lineTotal = round2(qty * price);

    // incluir fila solo si hay datos
    if (product || qty > 0 || price > 0) {
      rowsHtml += `<tr>
        <td>${escapeHtml(product)}</td>
        <td style="text-align:right">${formatNum(qty)}</td>
        <td style="text-align:right">${formatNum(price)}</td>
        <td style="text-align:right">${formatNum(lineTotal)}</td>
      </tr>`;
    }
  }

  // si no hay filas, indicar vacío
  if (!rowsHtml) {
    rowsHtml = `<tr><td colspan="4">No hay items seleccionados</td></tr>`;
  }

  // leer totales actuales (ya calculados en la UI)
  const subtotal = document.getElementById('subtotal').textContent;
  const vat = document.getElementById('vat').textContent;
  const total = document.getElementById('total').textContent;
  const ahora12_total = document.getElementById('ahora12_total').textContent;
  const ahora12_cuota = document.getElementById('ahora12_cuota').textContent;
  const ahora18_total = document.getElementById('ahora18_total').textContent;
  const ahora18_cuota = document.getElementById('ahora18_cuota').textContent;

  // HTML completo con estilo embebido para que el popup tenga estilo
  const html = `
  <!doctype html>
  <html lang="es">
  <head>
    <meta charset="utf-8" />
    <title>Presupuesto - ${escapeHtml(clientName)}</title>
    <style>
      body{font-family:Arial,Helvetica,sans-serif;padding:20px;color:#222}
      h2{margin:0 0 8px 0}
      .meta{margin-bottom:12px}
      table{width:100%;border-collapse:collapse;margin-top:8px}
      th,td{border:1px solid #ddd;padding:8px;text-align:left}
      th{background:#f5f5f5}
      .right{text-align:right}
      .totals{margin-top:12px; float:right; text-align:right; width:320px}
      .totals div{padding:4px 0}
    </style>
  </head>
  <body>
    <h2>Presupuesto</h2>
    <div class="meta">
      <div><strong>Cliente:</strong> ${escapeHtml(clientName)}</div>
      <div><strong>Fecha:</strong> ${escapeHtml(date)}</div>
    </div>

    <table>
      <thead>
        <tr><th>Producto</th><th>Cantidad</th><th>Precio u.</th><th>Total</th></tr>
      </thead>
      <tbody>
        ${rowsHtml}
      </tbody>
    </table>

    <div class="totals">
      <div>Subtotal: <strong>${subtotal}</strong></div>
      <div>IVA (21%): <strong>${vat}</strong></div>
      <div style="font-size:18px">Total con IVA: <strong>${total}</strong></div>
      <hr />
      <div>Ahora 12 — Total: <strong>${ahora12_total}</strong> / Cuota: <strong>${ahora12_cuota}</strong></div>
      <div>Ahora 18 — Total: <strong>${ahora18_total}</strong> / Cuota: <strong>${ahora18_cuota}</strong></div>
    </div>
  </body>
  </html>
  `;
  return html;
}

// pequeña función para escapar HTML y evitar inyecciones si el usuario pega HTML
function escapeHtml(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// limpiar formulario
function resetForm() {
  document.getElementById('clientName').value = '';
  for (let i = 1; i <= MAX_ROWS; i++) {
    document.getElementById(`product${i}`).selectedIndex = 0;
    document.getElementById(`qty${i}`).value = '';
    document.getElementById(`price${i}`).value = '';
    document.getElementById(`lineTotal${i}`).textContent = '0.00';
  }
  calculate();
}
